/**
 * Data Transfer Objects.
 */
package io.github.jhipster.gptm.service.dto;
