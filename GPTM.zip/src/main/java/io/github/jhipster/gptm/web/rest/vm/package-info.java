/**
 * View Models used by Spring MVC REST controllers.
 */
package io.github.jhipster.gptm.web.rest.vm;
