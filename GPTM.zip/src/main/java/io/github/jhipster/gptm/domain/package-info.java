/**
 * JPA domain objects.
 */
package io.github.jhipster.gptm.domain;
