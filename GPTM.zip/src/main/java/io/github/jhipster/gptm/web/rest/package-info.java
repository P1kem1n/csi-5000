/**
 * Spring MVC REST controllers.
 */
package io.github.jhipster.gptm.web.rest;
