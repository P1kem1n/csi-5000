/**
 * Spring Security configuration.
 */
package io.github.jhipster.gptm.security;
