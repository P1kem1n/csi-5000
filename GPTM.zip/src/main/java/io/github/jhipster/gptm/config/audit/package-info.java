/**
 * Audit specific code.
 */
package io.github.jhipster.gptm.config.audit;
