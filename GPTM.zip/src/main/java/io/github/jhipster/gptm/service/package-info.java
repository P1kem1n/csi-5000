/**
 * Service layer beans.
 */
package io.github.jhipster.gptm.service;
